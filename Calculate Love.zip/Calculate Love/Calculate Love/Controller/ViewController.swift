//
//  ViewController.swift
//  Calculate Love
//
//  Created by Apple on 10/29/17.
//  Copyright © 2017 Dusan Dimic. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet var OurView: UIView!
    
    @IBOutlet weak var coupleNamesLabel: UILabel!
    
    @IBOutlet weak var QuoteResult: UILabel!
    
    @IBOutlet weak var resultPercentage: UILabel!
    
    @IBOutlet weak var firstPersonField: UITextField!
    
    @IBOutlet weak var secondPersonField: UITextField!
    
    @IBOutlet weak var textFieldTopConstraint: NSLayoutConstraint!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        firstPersonField.delegate = self
        secondPersonField.delegate = self
        resultPercentage.isHidden = true
        QuoteResult.isHidden = true
        coupleNamesLabel.text = "Enter Lovebirds"
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(viewTapped))
        OurView.addGestureRecognizer(tapGesture)

        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func buttonCalcPressed(_ sender: UIButton) {
        getTheResults()
    }
    
    func getTheResults() {
        if firstPersonField.text == "" || secondPersonField.text == "" {
            QuoteResult.text = "Enter names correctly!"
            resultPercentage.isHidden = true
            coupleNamesLabel.isHidden = true
        }else{
            let randomNumber = arc4random_uniform(101)
            var resultString : String = ""
            if randomNumber < 30 {
                resultString = "Hell no, run away bro"
            }else if randomNumber > 30 && randomNumber < 50 {
                resultString = "Only if u have money"
            }else if randomNumber > 50 && randomNumber < 80 {
                resultString = "Yes, give it your best!"
            }else {
                resultString = "Marry this girl!"
            }
            QuoteResult.text = resultString
            resultPercentage.text = "\(randomNumber)%"
            let coupleNames : String = firstPersonField.text! + " and " + secondPersonField.text!
            coupleNamesLabel.text = coupleNames
            resultPercentage.isHidden = false
            QuoteResult.isHidden = false
            coupleNamesLabel.isHidden = false
        }
    }
    func textFieldDidBeginEditing(_ textField: UITextField) {
        UIView.animate(withDuration: 0.5) {
            self.textFieldTopConstraint.constant = 250
            self.view.layoutIfNeeded()
        }

    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        UIView.animate(withDuration: 0.5) {
            self.textFieldTopConstraint.constant = 298
            self.view.layoutIfNeeded()
        }
    }
    
    @objc func viewTapped(){
        firstPersonField.endEditing(true)
        secondPersonField.endEditing(true)
    }

}


